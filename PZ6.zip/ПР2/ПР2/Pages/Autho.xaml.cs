﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ПР2.Services;
namespace ПР2.Pages
{
    /// <summary>
    /// Логика взаимодействия для Autho.xaml
    /// </summary>
    public partial class Autho : Page
    {
        int click;

        public Autho()
        {
            InitializeComponent();
            click = 0;
        }

        private void btnEnterGuests_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Client(null));
        }

        private void GenerateCaptcha()
        {
            txtBlockCaptcha.Visibility = Visibility.Visible;
            txtBoxCaptcha.Visibility = Visibility.Visible;

            string captchaText = CaptchaGenerator.GenerateCaptchaText(6);
            txtBlockCaptcha.Text = captchaText;
            txtBlockCaptcha.TextDecorations = TextDecorations.Strikethrough;
        }

        private void btnEnter_Click(object sender, RoutedEventArgs e)
        {
            string login = txtLogin.Text.Trim();
            string password = txtPassword.Password.Trim();

            if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Введите логин и пароль!");
                return;
            }

            string hashedPassword = Hash.HashPassword(password);

            using (var db = new Shoe_FactoryEntities())
            {
                var user = db.Users.FirstOrDefault(x => x.Login == login && x.PasswordHash == hashedPassword);
                bool isUserValid = (user != null);
                string roleName = user != null ? user.Role : "Неизвестно";

                if (txtBoxCaptcha.Visibility == Visibility.Hidden)
                {
                    if (isUserValid)
                    {
                        MessageBox.Show("Вы вошли под: " + roleName);
                        LoadPage(roleName);
                    }
                    else
                    {
                        MessageBox.Show("Неверный логин или пароль! Введите капчу.");
                        GenerateCaptcha(); 
                        txtPassword.Clear();
                    }
                }
                else
                {
                    bool isCaptchaValid = txtBoxCaptcha.Text.Trim().ToLower() == txtBlockCaptcha.Text.ToLower();

                    if (isUserValid && isCaptchaValid)
                    {
                        MessageBox.Show("Вы вошли под: " + roleName);
                        LoadPage(roleName);
                    }
                    else
                    {
                        MessageBox.Show("Неверный логин, пароль или капча! Попробуйте снова.");
                        GenerateCaptcha(); 
                        txtBoxCaptcha.Clear();
                        txtPassword.Clear();
                    }
                }
            }
        }

        private void LoadPage(string _role)
        {
            click = 0;
            switch (_role)
            {
                case "admin":
                case "manager":
                case "Клиент":
                case "Пользователь":
                    NavigationService.Navigate(new Client(null));
                    break;
                default:
                    MessageBox.Show("Для роли " + _role + " страница еще не создана.");
                    break;
            }
        }
    }
}